import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;


class Custom_Class implements Writable {

	public Text recovered;
	public Text stolen;
	
	public Custom_Class() throws Exception{
		
		recovered= new Text();
		stolen=new Text();
	}
	
	public Custom_Class(String recovered, String stolen) throws Exception{
		
		this.recovered=new Text(recovered);
		this.stolen=new Text(stolen);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException{
		
		recovered.readFields(in);
		stolen.readFields(in);
	}
	
	@Override
	public void write(DataOutput out) throws IOException{
		
		recovered.write(out);
		stolen.write(out);
	}
	
	public Text getRecovered() throws Exception{
		
		return recovered;
	}
	
	public Text getStolen() throws Exception{
		
		return stolen;
	}
}

