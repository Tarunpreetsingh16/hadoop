
import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class StubReducer extends Reducer<Text, Custom_Class, Text, Text> {

  @Override
  public void reduce(Text key, Iterable<Custom_Class> values, Context context)
      throws IOException, InterruptedException {

    /*
     * TODO implement
     */
	  double sum_Stolen=0;
	  double sum_Recovered=0;
	  try{
		  for(Custom_Class i:values){
			  
			  sum_Stolen +=Double.parseDouble(i.getStolen().toString());
			  sum_Recovered +=Double.parseDouble(i.getRecovered().toString());
		  }
		  
		  double perc=sum_Recovered/sum_Stolen*100;
		  context.write(key,new Text(String.valueOf((long)perc)));
	  }
	  catch(Exception e){
		  
		  e.printStackTrace();
	  }
  }
}