import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Theft {

  public static void main(String[] args) throws Exception {

	Job job=new Job();
	job.setJarByClass(Theft.class);
	job.setJobName("Theft");
	
	job.setMapperClass(StubMapper.class);
	job.setReducerClass(StubReducer.class);
	
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(LongWritable.class);
	
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(IntWritable.class);
	
	Path output=new Path("/user/hdfs/minor/output/output_Theft"); //Output directory path in hdfs...
	//Path output=new Path("output_Theft");
	FileSystem fs=FileSystem.get(new Configuration());
	
	if(fs.exists(output)){
		
		fs.delete(output,true);
	}
	
	
	MultipleInputs.addInputPath(job,new Path("/user/hdfs/minor/data/17_Case_reported_and_value_of_property_taken_away_by_place_of_occurrence_2001_2012.csv"),TextInputFormat.class,StubMapper.class);
	MultipleInputs.addInputPath(job,new Path("/user/hdfs/minor/data/17_Case_reported_and_value_of_property_taken_away_by_place_of_occurrence_2013.csv"),TextInputFormat.class,StubMapper.class);
	
	//FileInputFormat.addInputPaths(job, "17_Case_reported_and_value_of_property_taken_away_by_place_of_occurrence_2001_2012.csv,17_Case_reported_and_value_of_property_taken_away_by_place_of_occurrence_2013.csv");
	FileOutputFormat.setOutputPath(job,output);
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
