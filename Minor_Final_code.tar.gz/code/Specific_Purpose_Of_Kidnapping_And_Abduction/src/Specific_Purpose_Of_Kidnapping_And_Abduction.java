import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Specific_Purpose_Of_Kidnapping_And_Abduction {

  public static void main(String[] args) throws Exception {

	Job job=new Job();
	job.setJarByClass(Specific_Purpose_Of_Kidnapping_And_Abduction.class);
	job.setJobName("Specific_Purpose_Of_Kidnapping_And_Abduction");
	
	job.setMapperClass(StubMapper.class);
	job.setReducerClass(StubReducer.class);
	
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(LongWritable.class);
	
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(IntWritable.class);
	
	Path output=new Path("/user/hdfs/minor/output/output_Specific_Purpose_Of_Kidnapping_And_Abduction"); //Output directory path in hdfs...
	//Path output=new Path("output_Specific_Purpose_Of_Kidnapping_And_Abduction");
	
	FileSystem fs=FileSystem.get(new Configuration());
	
	if(fs.exists(output)){
		
		fs.delete(output,true);
	}
	
	FileInputFormat.addInputPath(job,new Path("/user/hdfs/minor/data/39_Specific_purpose_of_kidnapping_and_abduction.csv"));
	//FileInputFormat.addInputPaths(job,"39_Specific_purpose_of_kidnapping_and_abduction.csv");
	FileOutputFormat.setOutputPath(job,output);
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
