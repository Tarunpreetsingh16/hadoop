import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Escape_From_Police_Custody {

  public static void main(String[] args) throws Exception {

	Job job=new Job();
	job.setJarByClass(Escape_From_Police_Custody.class);
	job.setJobName("Escape_From_Police_Custody");
	
	job.setMapperClass(StubMapper.class);
	job.setReducerClass(StubReducer.class);
	
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(LongWritable.class);
	
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(IntWritable.class);
	
	Path output=new Path("/user/hdfs/minor/output/output_Escape_From_Police_Custody"); //Output directory path in hdfs...
	
	FileSystem fs=FileSystem.get(new Configuration());
	
	if(fs.exists(output)){
		
		fs.delete(output,true);
	}
	
	FileInputFormat.addInputPath(job,new Path("/user/hdfs/minor/data/41_Escapes_from_police_custody.csv"));
	FileOutputFormat.setOutputPath(job,output);
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
