import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Murder_Victim_age_Group {

  public static void main(String[] args) throws Exception {

	Job job=new Job();
	job.setJarByClass(Murder_Victim_age_Group.class);
	job.setJobName("Murder_Victim_age_Group");
	
	job.setMapperClass(StubMapper.class);
	job.setReducerClass(StubReducer.class);
	
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(LongWritable.class);
	
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(IntWritable.class);
	
	Path output=new Path("/user/hdfs/minor/output/output_Murder_Victim_age_Group"); //Output directory path in hdfs...
	//Path output=new Path("output_Murder_Victim_age_Group");
	
	FileSystem fs=FileSystem.get(new Configuration());
	
	if(fs.exists(output)){
		
		fs.delete(output,true);
	}
	
	//FileInputFormat.addInputPaths(job,"/user/hdfs/minor/data/41_Escapes_from_police_custody.csv");
	FileInputFormat.addInputPath(job,new Path("/user/hdfs/minor/data/32_Murder_victim_age_sex.csv"));
	FileOutputFormat.setOutputPath(job,output);
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
