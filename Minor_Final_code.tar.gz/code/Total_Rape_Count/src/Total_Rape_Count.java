
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.hdfs.tools.GetConf;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Total_Rape_Count {

  public static void main(String[] args) throws Exception {

    /*
     * Validate that two arguments were passed from the command line.
     */
    Configuration conf=new Configuration();
	  Job job=Job.getInstance(conf);
	  job.setJarByClass(Total_Rape_Count.class);
	  job.setJobName("Total Crimes State Wise");
	  
	  job.setMapperClass(StubMapper.class);
	  job.setReducerClass(StubReducer.class);
	  
	  job.setOutputKeyClass(Text.class);
	  job.setOutputValueClass(LongWritable.class);
	  
	  job.setMapOutputKeyClass(Text.class);
	  job.setMapOutputValueClass(IntWritable.class);
	    
	  Path output=new Path("/user/hdfs/minor/output/output_Total_Rape_Count");
	  FileSystem fs = FileSystem.get(new Configuration());
	  
	  if(fs.exists(output)){
	   
	     fs.delete(output,true);
	  }
	  
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2001_2012.csv"), TextInputFormat.class, StubMapper.class);
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2013.csv"), TextInputFormat.class, StubMapper.class);
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2014.csv"), TextInputFormat.class, StubMapper.class);
	  
	  FileOutputFormat.setOutputPath(job, output);
    
	  System.exit(job.waitForCompletion(true)? 0 : 1);
  }
}
