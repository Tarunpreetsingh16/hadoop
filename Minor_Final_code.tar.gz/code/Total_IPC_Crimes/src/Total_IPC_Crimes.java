import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Total_IPC_Crimes {

  public static void main(String[] args) throws Exception {

    /*
     * Validate that two arguments were passed from the command line.
     */
    
	  Job job=new Job();
	  job.setJarByClass(Total_IPC_Crimes.class);
	  job.setJobName("Total Crimes State Wise");
	  
	  job.setMapperClass(StubMapper.class);
	  job.setReducerClass(StubReducer.class);
	  
	  job.setOutputKeyClass(Text.class);
	  job.setOutputValueClass(LongWritable.class);
	  
	  job.setMapOutputKeyClass(Text.class);
	  job.setMapOutputValueClass(IntWritable.class);
	  	  
	  Path output=new Path("/user/hdfs/minor/output/output_Total_IPC_Crimes");
	  FileSystem fs = FileSystem.get(new Configuration());
	  
	  if(fs.exists(output)){
	   
	     fs.delete(output,true);
	  }
	  
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2001_2012.csv"), TextInputFormat.class, StubMapper.class);
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2013.csv"), TextInputFormat.class, StubMapper.class);
	  MultipleInputs.addInputPath(job, new Path("/user/hdfs/minor/data/01_District_wise_crimes_committed_IPC_2014.csv"), TextInputFormat.class, StubMapper.class);
	  
	  FileOutputFormat.setOutputPath(job, output);
	  
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
