import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class StubMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

    /*
     * TODO implement
     */
	  String line=value.toString();
	  String a[]=line.split(",");
	  
	  try{
		  if((key.get()>=1))
		  {
			  context.write(new Text("Police_Injured_By_Criminals"),new IntWritable(Integer.parseInt(a[4])));
			  context.write(new Text("Police_Injured_By_Riotous_Mobs"),new IntWritable(Integer.parseInt(a[5])));
			  context.write(new Text("Police_Injured_In_Accidents"),new IntWritable(Integer.parseInt(a[6])));
			  context.write(new Text("Police_Injured_In_Dacoity_OperationsOther_raids"),new IntWritable(Integer.parseInt(a[7])));
			  context.write(new Text("Police_Injured_In_TerroristsExtremists_Operations"),new IntWritable(Integer.parseInt(a[8])));
			  context.write(new Text("Police_Injured_On_Border_Duties"),new IntWritable(Integer.parseInt(a[9])));
			  
			  context.write(new Text("Police_Killed_By_Criminals"),new IntWritable(Integer.parseInt(a[11])));
			  context.write(new Text("Police_Killed_By_Riotous_Mobs"),new IntWritable(Integer.parseInt(a[12])));
			  context.write(new Text("Police_Killed_In_Accidents"),new IntWritable(Integer.parseInt(a[13])));
			  context.write(new Text("Police_Killed_In_Dacoity_OperationsOther_raids"),new IntWritable(Integer.parseInt(a[14])));
			  context.write(new Text("Police_Killed_In_TerroristsExtremists_Operations"),new IntWritable(Integer.parseInt(a[15])));
			  context.write(new Text("Police_Killed_On_Border_Duties"),new IntWritable(Integer.parseInt(a[16])));
			  
			  
		  }
	  }
	  catch(Exception e){
		  
		  e.printStackTrace();
	  }
  }
}
